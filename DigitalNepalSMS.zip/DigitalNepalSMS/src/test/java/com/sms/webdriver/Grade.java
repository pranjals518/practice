package com.sms.webdriver;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.NoSuchElementException; 
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import java.util.List;


public class Grade {
	
	private static final String BASE_URL = "http://192.168.1.80:8080/sms/login";
	private static final String USERNAME = "digitalnepalsms";
	private static final String PASSWORD = "123456";
	
	public static void  main(String[] args) throws InterruptedException{
		System.setProperty("webdriver.chrome.driver", "C:\\Selenium\\chromedriver-win64\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get(BASE_URL);
		driver.manage().window().maximize();
		Thread.sleep(3000);
		
		driver.switchTo().activeElement().sendKeys(USERNAME);
		Thread.sleep(3000);
		
		driver.findElement(By.id("password")).sendKeys(PASSWORD);
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("//*[@id=\"btnLogin\"]")).click();
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("/html/body/header/nav/div[2]/ul/li[5]/a")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("/html/body/header/nav/div[2]/ul/li[5]/div/div/div[2]/ul/li[1]/ul/li[1]/a/span")).click();//Adding the grade
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[@id=\"create_grade\"]/div[1]/div[1]/div/input")).click(); //clicking on select grade.
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[@id=\"select-options-selectGradeAddPage\"]/li[8]/span")).click(); //clicking on one
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[@id=\"create_grade\"]/div[2]/button")).click(); //clicking the submit button.
		Thread.sleep(3000);
		
		//Now working on success message TC001
		try {
		WebElement successMessage = driver.findElement(By.className("jconfirm-content"));
	    
		System.out.println("msg: " + successMessage.getText());
	     
		if (successMessage.getText().contains("Grade saved successfully.")) {
			
			System.out.println("Test Case (Add Grade): Passed");
		} else {
            System.out.println("Test Case: Failed");
        }
		}catch (NoSuchElementException e) {
			
			System.out.println("Test Case (Add Grade): Failed");
		}
		Thread.sleep(5000);
		
		driver.findElement(By.xpath("/html/body/div[14]/div[2]/div/div/div/div/div/div/div/div[4]/button")).click(); //clicking the OK button
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("/html/body/header/nav/div[2]/ul/li[5]/a")).click(); //clicking the academic 
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("/html/body/header/nav/div[2]/ul/li[5]/div/div/div[2]/ul/li[1]/ul/li[2]/a/span")).click();  //clicking the view button
		Thread.sleep(3000);
		
		// Now check weather the grades window is displayed. TC002
		try {
			WebElement tableElement = driver.findElement(By.id("tableGrade"));// Locate the table element using its unique ID
		    
		    if(tableElement.isDisplayed()) {
		    	System.out.println("Test case (view grade): Passed ");
		    	
		    }
		    else {
		    	System.out.println("Test case failed");
		    	
		    }
					
		}catch (NoSuchElementException e) {
			System.out.println("Test case failed");
		}
		
		Thread.sleep(5000);
		
		
		
		
		
		
		
		
		driver.findElement(By.xpath("/html/body/header/nav/div[2]/ul/li[5]/a")).click(); //clicking the academic 
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("/html/body/header/nav/div[2]/ul/li[5]/div/div/div[2]/ul/li[1]/ul/li[3]/a/span")).click(); // click on Assign subject
		Thread.sleep(3000);
		
		
		
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofMillis(3000));
		WebElement dropdown = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"saveGradeSubject\"]/div[1]/div/div[2]/div/div/input"))); //click on drop down of select grade
		dropdown.click();
		WebElement option = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"select-options-selectGrade\"]/li[6]/span")));  //click on option of grade from drop down
		option.click();

	    Thread.sleep(3000);
	    
	    WebElement dropdowns = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"tblGradeSubject\"]/tbody/tr/td[2]/div/div"))); // click on drop down of select subject
	    dropdowns.click();
	    
	    
	    WebElement options = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"tblGradeSubject\"]/tbody/tr/td[2]/div/div/ul/li[2]")));  //click on option of subject from drop down
	    options.click();
	    
	    Thread.sleep(3000);
	    
	    
	    driver.findElement(By.name("code")).sendKeys("C.Math"); //sending the code of subject
	    Thread.sleep(3000);
	    driver.findElement(By.name("rank")).sendKeys(String.valueOf(2)); //sending the rank
	    Thread.sleep(3000);
	    driver.findElement(By.name("creditHours")).sendKeys(String.valueOf(40)); //sending the credit hours
	    Thread.sleep(3000);
	    driver.findElement(By.name("theory_full_marks")).sendKeys(String.valueOf(80)); //sending the FM of theory
	    Thread.sleep(3000);
	    driver.findElement(By.name("theory_pass_marks")).sendKeys(String.valueOf(30)); //sending the pass marks of theory
	    Thread.sleep(3000);
	    driver.findElement(By.name("practical_full_marks")).sendKeys(String.valueOf(20)); //sending the full marks of practical
	    Thread.sleep(3000);
	    driver.findElement(By.name("practical_pass_marks")).sendKeys(String.valueOf(8)); //sending the pass marks of practical
	    Thread.sleep(3000);
	    
	    
	    WebElement testfm = driver.findElement(By.name("test_full_marks"));

	 // Scroll the element into view
	 ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", testfm);
	 Thread.sleep(3000); // Add a wait to ensure the element is fully scrolled into view

	 // Input the value "50" into the input field
	 testfm.sendKeys(String.valueOf(50));

      // The above code is to scroll the window and find the element and input the value 50 for test full marks
	 
	    WebElement testpm = driver.findElement(By.name("test_pass_marks"));
	    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", testpm);
	    Thread.sleep(3000);
	    testpm.sendKeys(String.valueOf(20));
	    Thread.sleep(5000);
	    //The above code is to scroll the window and find the element and input the value 20 for test pass marks
	    
	    WebElement casfm = driver.findElement(By.name("cas_full_marks"));
	    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", casfm);
	    Thread.sleep(3000);
	    casfm.sendKeys(String.valueOf(100));
	    Thread.sleep(5000);
	    //The above code is to scroll the window and find the element and input the value 100 for CAS FM
        
	    WebElement caspm = driver.findElement(By.name("cas_pass_marks"));
	    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", caspm);
	    Thread.sleep(3000);
	    caspm.sendKeys(String.valueOf(40));
	    //The above code is to scroll the window and find the element and input the value 40 for CAS PM
	    
	    WebElement considerpm = driver.findElement(By.name("considerPassMarks"));
	    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", considerpm);
	    Thread.sleep(3000);
	    considerpm.sendKeys(String.valueOf(38));
	  //The above code is to scroll the window and find the element and input the value 38 for Consider pass marks
	    
	    WebElement gracmark = driver.findElement(By.name("graceMarks"));
	    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", gracmark);
	    Thread.sleep(3000);
	    gracmark.sendKeys(String.valueOf(2));
	  //The above code is to scroll the window and find the element and input the value 2 for grace marks
	    
	   
	    
	    driver.findElement(By.xpath("//*[@id=\"saveGradeSubject\"]/div[3]/button")).click(); //clicking the save button
	    Thread.sleep(5000);
	    
	    
	    driver.findElement(By.xpath("/html/body/div[12]/div[2]/div/div/div/div/div/div/div/div[4]/button[1]")).click(); //clicking the confirm save
	    Thread.sleep(3000);
	    
	    // Click the dropdown to open the options
	    WebElement dropdownElement = driver.findElement(By.xpath("//*[@id=\"tblGradeSubject\"]/tbody/tr/td[2]/div/div/input"));
	    dropdownElement.click();
	    Thread.sleep(3000);

	 
	    try {
	        WebElement desiredOption = driver.findElement(By.xpath("//*[@id=\"tblGradeSubject\"]/tbody/tr/td[2]/li[2]/span")); // Replace with the actual XPath of the desired option

	        
	        if (desiredOption.isDisplayed()) {
	            System.out.println("Test case Failed - Desired option is displayed");
	            
	        } else {
	            
	            System.out.println("Test case passed - Desired option not found");
	            // Add further actions if needed for the test case to be considered as passed
	        }

	    } catch (NoSuchElementException e) {
	        // If the desired option is not found, consider the test case passed
	        System.out.println("Test case passed - Desired option not found");
	        // Add further actions if needed for the test case to be considered as passed
	    }

	    
	    
	    
	    
	   
	    }
		
		
		
		
		
	}



