package com.sms.webdriver;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.NoSuchElementException; 
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import java.util.List;

public class Subject {
	private static final String BASE_URL = "http://192.168.1.80:8080/sms/login";
	private static final String USERNAME = "digitalnepalsms";
	private static final String PASSWORD = "123456";
	
	
	
	public static void main(String[] args) throws InterruptedException{
		
		System.setProperty("webdriver.chrome.driver", "C:\\Selenium\\chromedriver-win64\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get(BASE_URL);
		driver.manage().window().maximize();
		Thread.sleep(3000);
		
		driver.switchTo().activeElement().sendKeys(USERNAME);
		Thread.sleep(3000);
		
		driver.findElement(By.id("password")).sendKeys(PASSWORD);
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("//*[@id=\"btnLogin\"]")).click();     //clicking the login button
		Thread.sleep(3000);
		
		
		driver.findElement(By.xpath("/html/body/header/nav/div[2]/ul/li[5]/a")).click(); //clicking the academics
		Thread.sleep(3000); 
		
		driver.findElement(By.xpath("/html/body/header/nav/div[2]/ul/li[5]/div/div/div[3]/ul/li[2]/ul/li[1]/a/span")).click();  //clicking the add from the subject
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("//*[@id=\"tblBulkSubject\"]/tbody/tr/td[1]/input")).sendKeys("social");  // sending the name of the subject
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("//*[@id=\"tblBulkSubject\"]/tbody/tr/td[2]/input")).sendKeys("qkkkkyl");  // sending the short name
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("//*[@id=\"description\"]")).sendKeys("Literature is a very important subject");  // sending the description of the subject
		Thread.sleep(3000);
		
		driver.findElement(By.id("submit")).click();  // clicking the submit buttton
		Thread.sleep(5000);
		
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10)); // Wait for a maximum of 10 seconds
		WebElement okButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("/html/body/div[14]/div[2]/div/div/div/div/div/div/div/div[4]/button")));
		okButton.click();
		
		
		driver.findElement(By.xpath("/html/body/header/nav/div[2]/ul/li[5]/a")).click(); //clicking the academics
		Thread.sleep(3000); 
		
		driver.findElement(By.xpath("/html/body/header/nav/div[2]/ul/li[5]/div/div/div[3]/ul/li[2]/ul/li[2]/a/span")).click(); //clicking the view subject
		Thread.sleep(3000); 
		
		

		try {
		    
		    Thread.sleep(5000); 

		    // Find the first row of the table
		   WebElement firstRow = driver.findElement(By.xpath("//*[@id=\"subject_table\"]/tbody/tr[1]")); // Selecting the first row

		    // Check if the desired element (row) is present in the first row of the table
		    if (firstRow.getText().contains("social")) { 
		        System.out.println("Test case (Add Subject) - Passed ");
		        // Add further actions if needed for the test case to be considered as passed
		    } else {
		        System.out.println("Test case (Add Subject) - Failed ");
		        // Add further actions if needed for the test case to be considered as failed
		    }
		} catch (InterruptedException e) {
		    System.out.println("Thread interrupted while sleeping!");
		    // Handle the InterruptedException if needed
		} catch (NoSuchElementException e) {
		    System.out.println("Table not found");
		    // Handle the scenario where the table or first row is not found
		}
        
		
		// Now Code for Test case 2
		
		driver.findElement(By.xpath("/html/body/header/nav/div[2]/ul/li[5]/a")).click(); //clicking the academics
		Thread.sleep(3000); 
		
		driver.findElement(By.xpath("/html/body/header/nav/div[2]/ul/li[5]/div/div/div[3]/ul/li[2]/ul/li[2]/a/span")).click(); //clicking the view subject
		Thread.sleep(3000); 
		
		try {
			Thread.sleep(1000);
			
			driver.findElement(By.id("subject_table"));
			System.out.println("Test Case (View Subject) - Passed");
			
		}catch (NoSuchElementException e) {
			
			System.out.println("Test Case (View Subject) - Failed");
		}
		
		//Now test case for create ECA
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("/html/body/header/nav/div[2]/ul/li[5]/a")).click(); //clicking the academics
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("/html/body/header/nav/div[2]/ul/li[5]/div/div/div[3]/ul/li[2]/ul/li[3]/a/span")).click(); //clicking the create ECA
		Thread.sleep(5000);
		
		driver.findElement(By.xpath("//*[@id=\"name\"]")).sendKeys("Inter House Football Tournament"); //sending the name of the ECA
        Thread.sleep(3000);
        
       // driver.findElement(By.xpath("//*[@id=\"rank\"]")).sendKeys("String.valueOf(2)");    //sending the rank
        // Thread.sleep(3000);
        
        driver.findElement(By.xpath("//*[@id=\"ecaModal\"]/div/div/div[3]/button")).click(); //click on the submit button
        
        // Now giving the test case Pass/Fail message
        try {
        	WebDriverWait waits = new WebDriverWait(driver, Duration.ofSeconds(10)); // Wait for a maximum of 10 seconds
		    WebElement oksButton = waits.until(ExpectedConditions.elementToBeClickable(By.xpath("/html/body/div[14]/div[2]/div/div/div/div/div/div/div/div[4]/button")));
		    oksButton.click();
        	
        	System.out.println("Test case (Add ECA) - Passed");
        }
        catch (NoSuchElementException e) {
        	Thread.sleep(3000);
        	System.out.println("Test case (Add ECA) - Failed");
        }
        
        // Now writing the test case for view ECAs
        
        Thread.sleep(3000);
		
		driver.findElement(By.xpath("/html/body/header/nav/div[2]/ul/li[5]/a")).click(); //clicking the academics
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("/html/body/header/nav/div[2]/ul/li[5]/div/div/div[3]/ul/li[2]/ul/li[4]/a/span")).click();  //clicking the view ECAs
		Thread.sleep(3000);
		
		try {
			
		 WebElement tableElement = driver.findElement(By.id("eca_Table"));
		 if (tableElement.getText().contains("Rank")) {
	            System.out.println("Test case (view ECAs) - Passed.");
	        } else {
	            System.out.println("Test case (view ECAs) - Failed.");
	        }
		}catch (NoSuchElementException e) {
			Thread.sleep(3000);
			System.out.println("Test case (View ECAs) - Failed");
			System.out.println("Table not found");
		}
		
		
        		
	}
	

}

